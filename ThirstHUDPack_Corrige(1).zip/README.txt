Thirst HUD - pack corrige pour Minecraft Java 26.1
Police: thirst:hud
E000 = goutte pleine
E001 = goutte a moitie
E002 = goutte vide
